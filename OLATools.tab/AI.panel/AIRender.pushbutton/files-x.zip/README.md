# AI Render (pyRevit pushbutton)

Sends the active 3D view to a Gemini image model with a prompt built through
a WPF dialog, then places a before/after comparison on a new sheet using a
title block you pick from a live dropdown.

## Install

1. Copy this `AIRender.pushbutton` folder (all files: `bundle.yaml`,
   `script.py`, `ui.xaml`) into an existing panel, e.g.:
   `...\MyToolsExtension.extension\MyTools.tab\AI.panel\AIRender.pushbutton`
   (create the `AI.panel` folder if it doesn't exist — pyRevit picks up any
   `<name>.panel` folder automatically).
2. In pyRevit, click **Reload** (or restart Revit).

## Configure

1. Get an API key from Google AI Studio: https://aistudio.google.com/apikey
2. Enable billing on that key's project (image models have no free-tier
   quota — see https://ai.google.dev/gemini-api/docs/billing).
3. Set a Windows environment variable:
   - Name: `GEMINI_API_KEY`
   - Value: your key
   - **Fully close and relaunch Revit** afterward — env vars are only read
     once at process start, so a running Revit instance won't pick up a
     new or changed key.

No title block configuration needed — the dialog's dropdown is populated
live from whatever title block families/types are loaded in the current
project.

## Use

1. Open/activate a 3D view.
2. Click **AI Render**.
3. In the dialog:
   - Pick a **style** (photorealistic variants, sketch/illustration styles,
     and a few just-for-fun ones like sci-fi space station or cyberpunk).
   - Pick a **title block** for the comparison sheet.
   - Optionally pick from **Recent prompts** — your last 10 "extra
     direction" entries, most recent first, deduplicated. Selecting one
     fills the text box below with it (still editable afterward).
   - Type or edit **extra direction** (materials, mood, context).
   - Leave "Build a before/after comparison sheet" checked, or uncheck it
     for the drafting-view fallback instead.
4. A progress bar tracks export → API call → placement.
5. Result: a new sheet numbered `AI-001` (incrementing) named
   `AI Render - <view name>`, with the source view on the left labeled
   BEFORE, the AI result on the right labeled AFTER, and the prompt text
   underneath.

Style, title block, and extra-direction text are all remembered between
runs (and between Revit sessions) via pyRevit's own settings store.

If no title block is loaded in the project at all, the dropdown and
checkbox disable themselves automatically — you'll only get the drafting
view fallback until one's loaded.

## Why IronPython2, not CPython3

pyRevit's `pyrevit.forms` (which the WPF dialog depends on) only works on
the IronPython2 engine — it hard-fails on import under CPython3. So this
version uses IronPython2 throughout and calls the API with .NET's
`System.Net.WebClient` instead of the `requests` library; IronPython's
built-in `json` and `base64` modules cover the encoding side.

## Known interop quirks handled in this script

- **`Element.Name` AttributeError**: under IronPython, plain `element.Name`
  access can raise `AttributeError: Name` for some element types (title
  block symbols hit this in testing). Worked around with a helper
  (`_element_name()`) that binds to the base `Element.Name` property
  descriptor explicitly.
- **`WebClient` POST hangs on larger bodies**: some networks stall on the
  `Expect: 100-continue` handshake .NET sends before bigger POST payloads
  (like our base64 image). Disabled via `ServicePointManager.Expect100Continue`.
- **`ImageExportOptions.GetFileName()`**: this is a *static* method —
  `GetFileName(doc, viewId)` — not an instance call.

## Dialog styling

The dialog keeps Revit's native title bar (for reliability inside pyRevit's
window hosting) but restyles everything below it: a white rounded "card"
with a soft shadow sits on a light grey background, section labels are
small-caps grey, and the dropdowns/text box use rounded corners with a
custom flat style. All of this lives in `ui.xaml` under `Window.Resources`
— tweak colors/corner radius there if you want a different look.

## Things you'll likely want to adjust

- **Sheet layout**: `origin_x` / `origin_y` / `gap` in
  `create_before_after_sheet()` control where the images land and how far
  apart they are. Depending on your title block's origin point you may
  need to nudge these.
- **Sheet numbering**: auto-increments `AI-001`, `AI-002`, etc. — change
  the prefix in `next_sheet_number()` to match your project's convention.
- **Recent-prompts limit**: `MAX_RECENT_EXTRAS` near the top of
  `script.py` (currently 10).
- **The result is still a picture, not BIM geometry** — the AI restyles
  materials/lighting/atmosphere but can't hand back editable Revit
  elements.
- **Export resolution**: `PixelSize` in `export_view_to_image()` controls
  source image detail — currently lowered to 1000 for faster uploads while
  testing; raise it once you've confirmed the pipeline works reliably.
- **Model**: `GEMINI_MODEL` near the top is currently set to the cheap/fast
  `gemini-3.1-flash-lite-image` for testing. Switch to `gemini-3.1-flash-image`
  (full Nano Banana 2) for production-quality renders.
