# -*- coding: utf-8 -*-
"""
AI Render
---------
Exports the active 3D view to an image, sends it to an AI image-generation
API (default: Gemini 2.5 Flash Image, aka "Nano Banana") along with a
user-built prompt, then places BEFORE (source) and AFTER (AI result) images
side by side on a new sheet.

Runs on the IronPython2 engine (see bundle.yaml) because pyrevit.forms/WPF
does not work under pyRevit's CPython3 engine. The HTTP call uses .NET's
System.Net.WebClient instead of `requests`; IronPython's built-in json and
base64 modules handle encoding.

Setup:
  1. Get an API key from Google AI Studio (https://aistudio.google.com/apikey).
  2. Set it as a Windows environment variable named GEMINI_API_KEY, then
     restart Revit (env vars are read at process start).
  3. Update TITLEBLOCK_NAME below to match a title block family/type in
     your project (defaults to "AR_TS_DRH_A3-Horizontal").
  4. Activate a 3D view and click this button.
"""

import os
import json
import base64
from datetime import datetime

import clr
clr.AddReference("System")
from System.Net import WebClient, WebException
from System.IO import StreamReader

from pyrevit import revit, DB, forms, script

logger = script.get_logger()

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
GEMINI_MODEL = "gemini-2.5-flash-image"
GEMINI_ENDPOINT = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
)
API_KEY_ENV_VAR = "GEMINI_API_KEY"

TITLEBLOCK_NAME = "AR_TS_DRH_A3-Horizontal"  # change to match your project

EXPORT_FOLDER = os.path.join(os.environ.get("TEMP", os.getcwd()), "AIRender")

STYLE_PRESETS = [
    "Photorealistic, bright daylight",
    "Photorealistic, warm dusk / interior lighting",
    "Concept sketch, loose linework",
    "Soft watercolor illustration",
    "Clean line-art / technical illustration",
]


# ---------------------------------------------------------------------------
# WPF prompt window
# ---------------------------------------------------------------------------
class PromptForm(forms.WPFWindow):
    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)
        self.style_combo.ItemsSource = STYLE_PRESETS
        self.style_combo.SelectedIndex = 0
        self.result = None

    def render_click(self, sender, args):
        self.result = {
            "style": self.style_combo.SelectedItem,
            "extra": self.extra_box.Text or "",
            "build_sheet": bool(self.sheet_check.IsChecked),
        }
        self.Close()

    def cancel_click(self, sender, args):
        self.result = None
        self.Close()


def ask_for_prompt():
    xaml_path = script.get_bundle_file("ui.xaml")
    prompt_form = PromptForm(xaml_path)
    prompt_form.ShowDialog()

    if not prompt_form.result:
        script.exit()

    style = prompt_form.result["style"]
    extra = prompt_form.result["extra"]
    build_sheet = prompt_form.result["build_sheet"]

    prompt = (
        "Render this architectural 3D view as a {style} image. "
        "Preserve the exact geometry, proportions, and camera framing shown "
        "in the source image \u2014 only change materials, lighting, and "
        "atmosphere. {extra}"
    ).format(style=style[0].lower() + style[1:], extra=extra)

    return prompt, build_sheet


# ---------------------------------------------------------------------------
# Revit-side helpers
# ---------------------------------------------------------------------------
def get_api_key():
    key = os.environ.get(API_KEY_ENV_VAR)
    if not key:
        forms.alert(
            "No API key found.\n\n"
            "Set a Windows environment variable named '{}' with your "
            "Gemini API key, then restart Revit.".format(API_KEY_ENV_VAR),
            exitscript=True,
        )
    return key


def get_active_3d_view():
    view = revit.active_view
    if not isinstance(view, DB.View3D):
        forms.alert("Activate a 3D view before running AI Render.", exitscript=True)
    return view


def export_view_to_image(doc, view):
    if not os.path.exists(EXPORT_FOLDER):
        os.makedirs(EXPORT_FOLDER)

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filepath = os.path.join(EXPORT_FOLDER, "AIRenderSource_{}".format(stamp))

    options = DB.ImageExportOptions()
    options.FilePath = filepath
    options.ExportRange = DB.ExportRange.CurrentView
    options.ZoomType = DB.ZoomFitType.FitToPage
    options.PixelSize = 2000
    options.ImageResolution = DB.ImageResolution.DPI_300
    options.HLRandWFViewsFileType = DB.ImageFileType.PNG
    options.ShadowViewsFileType = DB.ImageFileType.PNG

    doc.ExportImage(options)

    produced_path = options.GetFileName()
    if not os.path.exists(produced_path):
        candidates = sorted(
            (f for f in os.listdir(EXPORT_FOLDER) if f.startswith(os.path.basename(filepath))),
            reverse=True,
        )
        if candidates:
            produced_path = os.path.join(EXPORT_FOLDER, candidates[0])
    return produced_path


# ---------------------------------------------------------------------------
# AI image API call (System.Net.WebClient, no `requests` dependency)
# ---------------------------------------------------------------------------
class _TimeoutWebClient(WebClient):
    """WebClient with a longer timeout for slow image-generation responses."""
    def GetWebRequest(self, address):
        request = WebClient.GetWebRequest(self, address)
        request.Timeout = 180000  # 3 minutes
        return request


def call_image_api(api_key, image_path, prompt):
    with open(image_path, "rb") as f:
        image_bytes = f.read()
    image_b64 = base64.b64encode(image_bytes)

    body = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {"inline_data": {"mime_type": "image/png", "data": image_b64}},
            ]
        }]
    }
    json_body = json.dumps(body)

    url = "{}?key={}".format(GEMINI_ENDPOINT.format(model=GEMINI_MODEL), api_key)

    client = _TimeoutWebClient()
    client.Headers.Add("Content-Type", "application/json")

    try:
        response_text = client.UploadString(url, "POST", json_body)
    except WebException as ex:
        details = ""
        if ex.Response:
            reader = StreamReader(ex.Response.GetResponseStream())
            details = reader.ReadToEnd()
        raise RuntimeError(
            "AI image API call failed: {} {}".format(ex.Message, details[:500])
        )

    data = json.loads(response_text)
    parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            return base64.b64decode(inline["data"])

    raise RuntimeError(
        "No image returned by the API. Response snippet: {}".format(response_text[:500])
    )


def save_result_image(image_bytes, source_path):
    result_path = source_path.replace("AIRenderSource", "AIRenderResult")
    if not result_path.lower().endswith(".png"):
        result_path += ".png"
    with open(result_path, "wb") as f:
        f.write(image_bytes)
    return result_path


# ---------------------------------------------------------------------------
# Before / after sheet
# ---------------------------------------------------------------------------
def get_titleblock_type(doc):
    collector = (
        DB.FilteredElementCollector(doc)
        .OfCategory(DB.BuiltInCategory.OST_TitleBlocks)
        .WhereElementIsElementType()
    )
    for symbol in collector:
        if symbol.Name == TITLEBLOCK_NAME:
            return symbol
    return None


def next_sheet_number(doc, prefix="AI-"):
    existing = set(s.SheetNumber for s in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet))
    i = 1
    while "{}{:03d}".format(prefix, i) in existing:
        i += 1
    return "{}{:03d}".format(prefix, i)


def create_before_after_sheet(doc, source_path, result_path, view_name, prompt_text):
    titleblock = get_titleblock_type(doc)
    if titleblock is None:
        forms.alert(
            "Title block '{}' not found in this project.\n\n"
            "Update TITLEBLOCK_NAME near the top of script.py to match a "
            "title block family/type you have loaded, then run again.".format(
                TITLEBLOCK_NAME
            ),
            exitscript=True,
        )

    text_type_id = doc.GetDefaultElementTypeId(DB.ElementTypeGroup.TextNoteType)

    with revit.Transaction("Create AI Render Comparison Sheet"):
        sheet = DB.ViewSheet.Create(doc, titleblock.Id)
        sheet.Name = "AI Render - {}".format(view_name)
        sheet.SheetNumber = next_sheet_number(doc)

        before_type = DB.ImageType.Create(
            doc, DB.ImageTypeOptions(source_path, False, DB.ImageTypeSource.Import)
        )
        after_type = DB.ImageType.Create(
            doc, DB.ImageTypeOptions(result_path, False, DB.ImageTypeSource.Import)
        )

        before_img = DB.ImageInstance.Create(
            doc, sheet, before_type.Id, DB.ImagePlacementOptions()
        )
        after_img = DB.ImageInstance.Create(
            doc, sheet, after_type.Id, DB.ImagePlacementOptions()
        )

        # Layout: two images side by side, starting near the sheet's
        # lower-left. Nudge ORIGIN_X/Y if your title block's origin differs.
        gap = 0.15       # ft between images (~1.8")
        origin_x = 0.5   # ft from sheet origin
        origin_y = 0.75  # ft from sheet origin

        before_pt = DB.XYZ(origin_x, origin_y, 0)
        before_img.SetLocation(before_pt, DB.BoxPlacement.BottomLeft)

        after_pt = DB.XYZ(origin_x + before_img.Width + gap, origin_y, 0)
        after_img.SetLocation(after_pt, DB.BoxPlacement.BottomLeft)

        label_gap = 0.15
        DB.TextNote.Create(
            doc, sheet.Id,
            DB.XYZ(before_pt.X, before_pt.Y + before_img.Height + label_gap, 0),
            before_img.Width, "BEFORE", DB.TextNoteOptions(text_type_id),
        )
        DB.TextNote.Create(
            doc, sheet.Id,
            DB.XYZ(after_pt.X, after_pt.Y + after_img.Height + label_gap, 0),
            after_img.Width, "AFTER", DB.TextNoteOptions(text_type_id),
        )
        DB.TextNote.Create(
            doc, sheet.Id,
            DB.XYZ(before_pt.X, origin_y - label_gap, 0),
            before_img.Width + gap + after_img.Width,
            "Prompt: {}".format(prompt_text),
            DB.TextNoteOptions(text_type_id),
        )

    return sheet


def place_image_on_drafting_view(doc, image_path, view_name):
    """Fallback used when the before/after sheet is skipped."""
    existing = list(DB.FilteredElementCollector(doc).OfClass(DB.ViewDrafting))
    drafting_view = next((v for v in existing if v.Name == view_name), None)

    with revit.Transaction("Place AI Render"):
        if drafting_view is None:
            view_family_type = next(
                vft for vft in DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType)
                if vft.ViewFamily == DB.ViewFamily.Drafting
            )
            drafting_view = DB.ViewDrafting.Create(doc, view_family_type.Id)
            drafting_view.Name = view_name

        image_type = DB.ImageType.Create(
            doc, DB.ImageTypeOptions(image_path, False, DB.ImageTypeSource.Import)
        )
        DB.ImageInstance.Create(doc, drafting_view, image_type.Id, DB.ImagePlacementOptions())

    return drafting_view


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    doc = revit.doc
    api_key = get_api_key()
    view = get_active_3d_view()
    prompt, build_sheet = ask_for_prompt()

    with forms.ProgressBar(title="AI Render ({value} of {max_value})") as pb:
        pb.update_progress(1, 4)
        source_image = export_view_to_image(doc, view)

        pb.update_progress(2, 4)
        image_bytes = call_image_api(api_key, source_image, prompt)

        pb.update_progress(3, 4)
        result_image = save_result_image(image_bytes, source_image)

        pb.update_progress(4, 4)
        if build_sheet:
            target = create_before_after_sheet(
                doc, source_image, result_image, view.Name, prompt
            )
            target_desc = "sheet '{}'".format(target.SheetNumber)
        else:
            target = place_image_on_drafting_view(
                doc, result_image, "AI Render - {}".format(view.Name)
            )
            target_desc = "drafting view '{}'".format(target.Name)

    forms.alert(
        "Done \u2014 placed on {}.".format(target_desc),
        title="AI Render Complete",
    )


if __name__ == "__main__":
    main()
