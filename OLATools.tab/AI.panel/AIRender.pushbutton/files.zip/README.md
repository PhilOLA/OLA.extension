# AI Render (pyRevit pushbutton)

Sends the active 3D view to Gemini 2.5 Flash Image ("Nano Banana") with a
prompt built through a WPF dialog, then places a before/after comparison
on a new sheet.

## Install

1. Copy this `AIRender.pushbutton` folder (all three files: `bundle.yaml`,
   `script.py`, `ui.xaml`) into an existing panel, e.g.:
   `...\MyToolsExtension.extension\MyTools.tab\AI.panel\AIRender.pushbutton`
   (create the `AI.panel` folder if it doesn't exist — pyRevit picks up any
   `<name>.panel` folder automatically).
2. In pyRevit, click **Reload** (or restart Revit).

## Configure

1. Get an API key from Google AI Studio: https://aistudio.google.com/apikey
2. Set a Windows environment variable:
   - Name: `GEMINI_API_KEY`
   - Value: your key
   - Restart Revit afterward (env vars are read once at process start).
3. Open `script.py` and set `TITLEBLOCK_NAME` to a title block family/type
   you actually have loaded (defaults to `"AR_TS_DRH_A3-Horizontal"`).

## Use

1. Open/activate a 3D view.
2. Click **AI Render**.
3. In the dialog: pick a style, optionally add extra direction, leave
   "Build a before/after comparison sheet" checked (or uncheck it to just
   drop the result on a drafting view instead).
4. A progress bar tracks export → API call → placement.
5. Result: a new sheet numbered `AI-001` (incrementing) named
   `AI Render - <view name>`, with the source view on the left labeled
   BEFORE, the AI result on the right labeled AFTER, and the prompt text
   underneath.

## Why IronPython2, not CPython3

pyRevit's `pyrevit.forms` (which the WPF dialog depends on) only works on
the IronPython2 engine — it hard-fails on import under CPython3. So this
version uses IronPython2 throughout and calls the API with .NET's
`System.Net.WebClient` instead of the `requests` library; IronPython's
built-in `json` and `base64` modules cover the encoding side, so nothing
extra needs installing.

## Things you'll likely want to adjust

- **Sheet layout**: `origin_x` / `origin_y` / `gap` in
  `create_before_after_sheet()` control where the images land and how far
  apart they are. Depending on your title block's origin point you may
  need to nudge these — try it once and adjust.
- **Sheet numbering**: currently auto-increments `AI-001`, `AI-002`, etc.
  Change the prefix in `next_sheet_number()` if you'd rather match your
  project's sheet numbering convention.
- **The result is still a picture, not BIM geometry** — the AI restyles
  materials/lighting/atmosphere but can't hand back editable Revit
  elements.
- **Export resolution**: `PixelSize = 2000` in `export_view_to_image()`
  controls how detailed the source image (and therefore the AI's working
  image) is — raise it for higher-quality results at the cost of a slower
  upload.
