# -*- coding: utf-8 -*-
"""
AI Arch Video
-------------
Exports the active 3D view, renders it as a still (Gemini/Nano Banana),
then animates that still into a short architectural walkthrough video using
Luma Ray 3.2 (Luma Agents API). Since Revit sheets/views cannot embed or
play video, the result is saved as an .mp4 to Documents\AIRender and shown
in an inline preview panel within the same window.

API docs sourced directly from docs.agents.lumalabs.ai (June 2026 Ray 3.2).

Setup:
  1. Same GEMINI_API_KEY environment variable as AI Render - already set.
  2. Get a Luma API key from https://platform.lumalabs.ai/
     Set it as LUMA_AGENTS_API_KEY in Windows env vars, restart Revit.
  3. Add credits at platform.lumalabs.ai (pay-as-you-go, no minimum).
"""

import os
import json
import time
import base64
from datetime import datetime

import clr
clr.AddReference("System")
from System.Net import WebClient, WebException, ServicePointManager
from System.IO import StreamReader, File as DotNetFile
from System.Text import Encoding
clr.AddReference("PresentationCore")
from System.Windows import Visibility
from System.Windows.Media.Imaging import BitmapImage
from System import Uri, Action
from System.Threading import Thread, ThreadStart
from System.Diagnostics import Process

# Disable Expect: 100-continue (known cause of WebClient POST hangs on
# larger payloads like base64 images on this network).
ServicePointManager.Expect100Continue = False

from pyrevit import revit, DB, forms, script

logger = script.get_logger()

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
IMAGE_QUALITY_PRESETS = [
    ("Draft  (fastest, cheapest)", "gemini-3.1-flash-lite-image"),
    ("Standard", "gemini-3.1-flash-image"),
    ("Final  (Pro quality, slower)", "gemini-3-pro-image"),
]

VIDEO_QUALITY_PRESETS = [
    ("720p  5s  — SDR (fastest, cheapest)", "720p", "5s", False),
    ("1080p 5s  — SDR", "1080p", "5s", False),
    ("720p  5s  — HDR (best colour accuracy)", "720p", "5s", True),
    ("1080p 5s  — HDR", "1080p", "5s", True),
]

STYLE_PRESETS = [
    "Photorealistic, bright daylight",
    "Photorealistic, early morning light",
    "Photorealistic, warm dusk / interior lighting",
    "Photorealistic, dusk with exterior/landscape lighting",
    "Concept sketch, loose linework",
    "Soft watercolor illustration",
    "Clean line-art / technical illustration",
    "Sci-fi space station",
    "Cyberpunk neon night",
    "Fantasy castle interior",
    "Underwater research station",
    "Retro-futuristic 1960s",
]

# Gemini still-image endpoint (same as AI Render / AI Walkthrough)
GEMINI_IMAGE_ENDPOINT = (
    "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
)

# Luma Agents API (Ray 3.2) - from docs.agents.lumalabs.ai
LUMA_SUBMIT_ENDPOINT = "https://agents.lumalabs.ai/v1/generations"
LUMA_POLL_ENDPOINT = "https://agents.lumalabs.ai/v1/generations/{id}"

GEMINI_API_KEY_ENV = "GEMINI_API_KEY"
LUMA_API_KEY_ENV = "LUMA_AGENTS_API_KEY"

EXPORT_FOLDER = os.path.join(
    os.environ.get("USERPROFILE", os.getcwd()), "Documents", "AIRender"
)

UPLOAD_MAX_ATTEMPTS = 3
UPLOAD_RETRY_DELAY_SECONDS = 5
POLL_INTERVAL_SECONDS = 10
MAX_POLL_ATTEMPTS = 60          # 10 minutes max - Luma can take longer on HDR
INITIAL_POLL_WAIT_SECONDS = 15  # Luma says don't poll immediately

MAX_RECENT_EXTRAS = 10
MAX_RECENT_MOTIONS = 10
RECENT_PLACEHOLDER = "Select a recent prompt..."
RECENT_EMPTY_PLACEHOLDER = "No recent prompts yet"


# ---------------------------------------------------------------------------
# Remembered settings
# ---------------------------------------------------------------------------
def load_last_settings():
    config = script.get_config()
    last_style_index = getattr(config, "archvideo_style_index", 0)
    if not isinstance(last_style_index, int) or not (0 <= last_style_index < len(STYLE_PRESETS)):
        last_style_index = 0
    last_image_quality_index = getattr(config, "archvideo_image_quality_index", 0)
    if not isinstance(last_image_quality_index, int) or not (
        0 <= last_image_quality_index < len(IMAGE_QUALITY_PRESETS)
    ):
        last_image_quality_index = 0
    last_video_quality_index = getattr(config, "archvideo_video_quality_index", 0)
    if not isinstance(last_video_quality_index, int) or not (
        0 <= last_video_quality_index < len(VIDEO_QUALITY_PRESETS)
    ):
        last_video_quality_index = 0
    last_extra = getattr(config, "archvideo_last_extra", "")
    last_motion = getattr(config, "archvideo_last_motion", "")
    return last_style_index, last_image_quality_index, last_video_quality_index, last_extra, last_motion


def get_recent_extras():
    config = script.get_config()
    recent = getattr(config, "archvideo_recent_extras", None)
    return recent if isinstance(recent, list) else []


def push_recent_extra(recent, new_extra):
    new_extra = (new_extra or "").strip()
    if not new_extra:
        return recent
    updated = [new_extra] + [e for e in recent if e != new_extra]
    return updated[:MAX_RECENT_EXTRAS]


def get_recent_motions():
    config = script.get_config()
    recent = getattr(config, "archvideo_recent_motions", None)
    return recent if isinstance(recent, list) else []


def push_recent_motion(recent, new_motion):
    new_motion = (new_motion or "").strip()
    if not new_motion:
        return recent
    updated = [new_motion] + [m for m in recent if m != new_motion]
    return updated[:MAX_RECENT_MOTIONS]


def save_last_settings(style_index, image_quality_index, video_quality_index,
                        extra, recent_extras, motion, recent_motions):
    config = script.get_config()
    config.archvideo_style_index = style_index
    config.archvideo_image_quality_index = image_quality_index
    config.archvideo_video_quality_index = video_quality_index
    config.archvideo_last_extra = extra
    config.archvideo_recent_extras = recent_extras
    config.archvideo_last_motion = motion
    config.archvideo_recent_motions = recent_motions
    script.save_config()


# ---------------------------------------------------------------------------
# WPF prompt window (settings / progress / preview in one window)
# ---------------------------------------------------------------------------
def build_still_prompt(style, extra):
    return (
        "Render this architectural 3D view as a {style} image. "
        "Preserve the exact geometry, proportions, and camera framing shown "
        "in the source image — only change materials, lighting, and "
        "atmosphere. {extra}"
    ).format(style=style[0].lower() + style[1:], extra=extra)


def build_motion_prompt(motion):
    return motion.strip() or (
        "Slow, cinematic camera movement exploring the architecture. "
        "Gentle lateral drift or subtle push-in, natural environmental "
        "motion (light shifting, foliage swaying gently). Architecture "
        "stays the clear focus throughout. No dialogue."
    )


class PromptForm(forms.WPFWindow):
    def __init__(self, xaml_file, doc, view, gemini_key, luma_key,
                 last_style_index, last_image_quality_index, last_video_quality_index,
                 last_extra, recent_extras, last_motion, recent_motions):
        forms.WPFWindow.__init__(self, xaml_file)
        self.doc = doc
        self.view = view
        self.gemini_key = gemini_key
        self.luma_key = luma_key
        self.recent_extras = recent_extras or []
        self.recent_motions = recent_motions or []
        self.video_path = None
        self._closed = False
        self.Closed += self.on_window_closed

        self.style_combo.ItemsSource = STYLE_PRESETS
        self.style_combo.SelectedIndex = last_style_index

        self.image_quality_combo.ItemsSource = [label for label, _ in IMAGE_QUALITY_PRESETS]
        self.image_quality_combo.SelectedIndex = last_image_quality_index

        self.video_quality_combo.ItemsSource = [label for label, _, _, _ in VIDEO_QUALITY_PRESETS]
        self.video_quality_combo.SelectedIndex = last_video_quality_index

        self.extra_box.Text = last_extra
        if self.recent_extras:
            self.recent_extra_combo.ItemsSource = [RECENT_PLACEHOLDER] + self.recent_extras
            self.recent_extra_combo.IsEnabled = True
        else:
            self.recent_extra_combo.ItemsSource = [RECENT_EMPTY_PLACEHOLDER]
            self.recent_extra_combo.IsEnabled = False
        self.recent_extra_combo.SelectedIndex = 0

        self.motion_box.Text = last_motion
        if self.recent_motions:
            self.recent_motion_combo.ItemsSource = [RECENT_PLACEHOLDER] + self.recent_motions
            self.recent_motion_combo.IsEnabled = True
        else:
            self.recent_motion_combo.ItemsSource = [RECENT_EMPTY_PLACEHOLDER]
            self.recent_motion_combo.IsEnabled = False
        self.recent_motion_combo.SelectedIndex = 0

        try:
            logo_path = script.get_bundle_file("logo.png")
            self.logo_image.Source = BitmapImage(Uri(logo_path))
        except Exception:
            pass

    # -- settings panel handlers ----------------------------------------
    def recent_extra_combo_changed(self, sender, args):
        if self.recent_extra_combo.SelectedIndex <= 0:
            return
        self.extra_box.Text = self.recent_extra_combo.SelectedItem
        self.recent_extra_combo.SelectedIndex = 0

    def recent_motion_combo_changed(self, sender, args):
        if self.recent_motion_combo.SelectedIndex <= 0:
            return
        self.motion_box.Text = self.recent_motion_combo.SelectedItem
        self.recent_motion_combo.SelectedIndex = 0

    def render_click(self, sender, args):
        style = self.style_combo.SelectedItem
        extra = self.extra_box.Text or ""
        image_quality_index = self.image_quality_combo.SelectedIndex
        video_quality_index = self.video_quality_combo.SelectedIndex
        motion = self.motion_box.Text or ""

        updated_recent_extras = push_recent_extra(self.recent_extras, extra)
        updated_recent_motions = push_recent_motion(self.recent_motions, motion)
        save_last_settings(
            STYLE_PRESETS.index(style), image_quality_index, video_quality_index,
            extra, updated_recent_extras, motion, updated_recent_motions
        )
        self.recent_extras = updated_recent_extras
        self.recent_motions = updated_recent_motions

        _, image_model_id = IMAGE_QUALITY_PRESETS[image_quality_index]
        _, vid_resolution, vid_duration, vid_hdr = VIDEO_QUALITY_PRESETS[video_quality_index]

        still_prompt = build_still_prompt(style, extra)
        motion_prompt = build_motion_prompt(motion)

        self.settings_panel.Visibility = Visibility.Collapsed
        self.progress_panel.Visibility = Visibility.Visible
        self.progress_status_text.Text = "Exporting the active 3D view..."

        try:
            source_image = export_view_to_image(self.doc, self.view)
        except Exception as ex:
            self._show_error("Couldn't export the view: {}".format(ex))
            return

        worker = ThreadStart(
            lambda: self._generate_worker(
                source_image, still_prompt, motion_prompt,
                image_model_id, vid_resolution, vid_duration, vid_hdr
            )
        )
        thread = Thread(worker)
        thread.IsBackground = True
        thread.Start()

    def cancel_click(self, sender, args):
        self.Close()

    def on_window_closed(self, sender, args):
        self._closed = True

    # -- background worker (all network calls) --------------------------
    def _generate_worker(self, source_image, still_prompt, motion_prompt,
                          image_model_id, vid_resolution, vid_duration, vid_hdr):
        try:
            self._set_status(
                "Generating still image... ☕ grab a coffee, back in a moment"
            )
            image_bytes = call_image_api(self.gemini_key, source_image, still_prompt, image_model_id)
            still_path = save_still_image(image_bytes, source_image)

            self._set_status(
                "Generating video with Luma Ray 3.2 — this can take a few minutes... ☕ have some more coffee"
            )

            def on_poll_progress(attempt, max_attempts):
                elapsed_min = (attempt * POLL_INTERVAL_SECONDS) // 60
                self._set_status(
                    "Generating video with Luma Ray 3.2 — "
                    "(~{} min elapsed) ☕ have some more coffee".format(elapsed_min)
                )

            video_bytes = call_luma_api(
                self.luma_key, still_path, motion_prompt,
                vid_resolution, vid_duration, vid_hdr, on_poll_progress
            )

            self._set_status("Saving video...")
            video_path = save_video(video_bytes, still_path)
            self._show_preview(video_path)

        except Exception as ex:
            self._show_error(str(ex))

    # -- thread-safe UI updates -----------------------------------------
    def _set_status(self, text):
        try:
            self.Dispatcher.BeginInvoke(Action(lambda: self._set_status_ui(text)))
        except Exception:
            pass

    def _set_status_ui(self, text):
        if self._closed:
            return
        self.progress_status_text.Text = text

    def _show_error(self, message):
        try:
            self.Dispatcher.BeginInvoke(Action(lambda: self._show_error_ui(message)))
        except Exception:
            pass

    def _show_error_ui(self, message):
        if self._closed:
            return
        self.progress_status_text.Text = "Something went wrong:\n{}".format(message)

    def _show_preview(self, video_path):
        try:
            self.Dispatcher.BeginInvoke(Action(lambda: self._show_preview_ui(video_path)))
        except Exception:
            pass

    def _show_preview_ui(self, video_path):
        if self._closed:
            return
        self.video_path = video_path
        self.progress_panel.Visibility = Visibility.Collapsed
        self.preview_panel.Visibility = Visibility.Visible
        self.preview_status_text.Text = video_path
        try:
            self.video_player.Source = Uri(video_path)
            self.video_player.Play()
        except Exception as ex:
            self.preview_status_text.Text = (
                "Couldn't start the preview ({}). The video is still "
                "saved to:\n{}"
            ).format(ex, video_path)

    # -- preview panel handlers -----------------------------------------
    def video_ended(self, sender, args):
        from System import TimeSpan
        self.video_player.Position = TimeSpan.Zero
        self.video_player.Play()

    def video_failed(self, sender, args):
        self.preview_status_text.Text = (
            "Couldn't preview the video in this window. The file is fine "
            "— saved to:\n{}"
        ).format(self.video_path)

    def open_folder_click(self, sender, args):
        if self.video_path:
            open_containing_folder(self.video_path)

    def new_render_click(self, sender, args):
        try:
            self.video_player.Stop()
        except Exception:
            pass
        self.preview_panel.Visibility = Visibility.Collapsed
        self.settings_panel.Visibility = Visibility.Visible

    def close_click(self, sender, args):
        try:
            self.video_player.Stop()
        except Exception:
            pass
        self.Close()


# ---------------------------------------------------------------------------
# Revit-side helpers
# ---------------------------------------------------------------------------
def get_gemini_key():
    key = os.environ.get(GEMINI_API_KEY_ENV)
    if not key:
        forms.alert(
            "No Gemini API key found.\n\n"
            "Set a Windows environment variable named '{}' and restart "
            "Revit.".format(GEMINI_API_KEY_ENV),
            exitscript=True,
        )
    return key


def get_luma_key():
    key = os.environ.get(LUMA_API_KEY_ENV)
    if not key:
        forms.alert(
            "No Luma API key found.\n\n"
            "Get one at https://platform.lumalabs.ai/, set a Windows "
            "environment variable named '{}', and restart "
            "Revit.".format(LUMA_API_KEY_ENV),
            exitscript=True,
        )
    return key


def get_active_3d_view():
    view = revit.active_view
    if not isinstance(view, DB.View3D):
        forms.alert("Activate a 3D view before running AI Arch Video.", exitscript=True)
    return view


def export_view_to_image(doc, view):
    if not os.path.exists(EXPORT_FOLDER):
        os.makedirs(EXPORT_FOLDER)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    filepath = os.path.join(EXPORT_FOLDER, "AIArchVideoSource_{}".format(stamp))
    options = DB.ImageExportOptions()
    options.FilePath = filepath
    options.ExportRange = DB.ExportRange.CurrentView
    options.ZoomType = DB.ZoomFitType.FitToPage
    options.PixelSize = 1000
    options.ImageResolution = DB.ImageResolution.DPI_300
    options.HLRandWFViewsFileType = DB.ImageFileType.PNG
    options.ShadowViewsFileType = DB.ImageFileType.PNG
    doc.ExportImage(options)
    produced_path = DB.ImageExportOptions.GetFileName(doc, view.Id)
    if not os.path.exists(produced_path):
        candidates = sorted(
            (f for f in os.listdir(EXPORT_FOLDER) if f.startswith(os.path.basename(filepath))),
            reverse=True,
        )
        if candidates:
            produced_path = os.path.join(EXPORT_FOLDER, candidates[0])
    return produced_path


def open_containing_folder(file_path):
    try:
        Process.Start("explorer.exe", '/select,"{}"'.format(file_path))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# HTTP helpers (shared retry-wrapped POST, same pattern as AI Walkthrough)
# ---------------------------------------------------------------------------
class _TimeoutWebClient(WebClient):
    def GetWebRequest(self, address):
        request = WebClient.GetWebRequest(self, address)
        request.Timeout = 300000  # 5 minutes
        request.KeepAlive = False
        return request


def _upload_with_retry(url, json_body, auth_header):
    """POST json_body to url with retry on transient network failures.
    Pass an empty string for auth_header when auth is in the URL (Gemini)."""
    last_error = None
    for attempt in range(UPLOAD_MAX_ATTEMPTS):
        client = _TimeoutWebClient()
        client.Encoding = Encoding.UTF8
        client.Headers.Add("Content-Type", "application/json")
        if auth_header:
            client.Headers.Add("Authorization", auth_header)
        try:
            return client.UploadString(url, "POST", json_body)
        except WebException as ex:
            last_error = ex
            if attempt < UPLOAD_MAX_ATTEMPTS - 1:
                time.sleep(UPLOAD_RETRY_DELAY_SECONDS)
    details = ""
    if last_error.Response:
        reader = StreamReader(last_error.Response.GetResponseStream())
        details = reader.ReadToEnd()
    raise RuntimeError("Request failed: {} {}".format(last_error.Message, details[:500]))


def _get_json(url, auth_header):
    """GET url and return the parsed JSON body."""
    client = _TimeoutWebClient()
    if auth_header:
        client.Headers.Add("Authorization", auth_header)
    try:
        return json.loads(client.DownloadString(url))
    except WebException as ex:
        details = ""
        if ex.Response:
            reader = StreamReader(ex.Response.GetResponseStream())
            details = reader.ReadToEnd()
        raise RuntimeError("GET failed: {} {}".format(ex.Message, details[:500]))


def _download_bytes(url):
    client = _TimeoutWebClient()
    try:
        return client.DownloadData(url)
    except WebException as ex:
        raise RuntimeError("Download failed: {}".format(ex.Message))


# ---------------------------------------------------------------------------
# Gemini still-image generation (same as AI Walkthrough)
# ---------------------------------------------------------------------------
def call_image_api(api_key, image_path, prompt, model_id):
    with open(image_path, "rb") as f:
        image_bytes = f.read()
    image_b64 = base64.b64encode(image_bytes)
    body = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {"inline_data": {"mime_type": "image/png", "data": image_b64}},
            ]
        }]
    }
    url = "{}?key={}".format(GEMINI_IMAGE_ENDPOINT.format(model=model_id), api_key)
    response_text = _upload_with_retry(url, json.dumps(body), "")
    data = json.loads(response_text)
    parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            return base64.b64decode(inline["data"])
    raise RuntimeError(
        "No image returned by the Gemini API. Response: {}".format(response_text[:500])
    )


def save_still_image(image_bytes, source_path):
    result_path = source_path.replace("AIArchVideoSource", "AIArchVideoStill")
    if not result_path.lower().endswith(".png"):
        result_path += ".png"
    with open(result_path, "wb") as f:
        f.write(image_bytes)
    return result_path


# ---------------------------------------------------------------------------
# Luma Ray 3.2 video generation (Luma Agents API)
# REST schema from docs.agents.lumalabs.ai - fetched 2026-08-29
#
# Key facts from the live docs:
#   - Endpoint:  POST https://agents.lumalabs.ai/v1/generations
#   - Auth:      Authorization: Bearer <LUMA_AGENTS_API_KEY>
#   - Image ref: video.start_frame.data (inline base64) + media_type
#   - Duration:  "5s" or "10s" as strings  (10s incompatible with start_frame)
#   - Poll:      GET /v1/generations/{id} until state == "completed"/"failed"
#   - Download:  output[0].url  (presigned, expires 1 hour - download promptly)
# ---------------------------------------------------------------------------
def call_luma_api(luma_key, still_image_path, motion_prompt,
                  resolution, duration, hdr, progress_callback=None):
    with open(still_image_path, "rb") as f:
        image_bytes = f.read()
    image_b64 = base64.b64encode(image_bytes)

    body = {
        "model": "ray-3.2",
        "type": "video",
        "prompt": motion_prompt,
        "aspect_ratio": "16:9",
        "video": {
            "resolution": resolution,
            "duration": duration,
            "hdr": hdr,
            "start_frame": {
                "data": image_b64,
                "media_type": "image/png",
            },
        },
    }

    auth = "Bearer {}".format(luma_key)
    response_text = _upload_with_retry(LUMA_SUBMIT_ENDPOINT, json.dumps(body), auth)
    submit_data = json.loads(response_text)
    generation_id = submit_data.get("id")
    if not generation_id:
        raise RuntimeError(
            "Luma API didn't return a generation ID. Response: {}".format(response_text[:500])
        )

    poll_url = LUMA_POLL_ENDPOINT.format(id=generation_id)

    # Luma docs say: "don't bother polling right away"
    time.sleep(INITIAL_POLL_WAIT_SECONDS)

    for attempt in range(MAX_POLL_ATTEMPTS):
        if progress_callback:
            progress_callback(attempt, MAX_POLL_ATTEMPTS)

        status_data = _get_json(poll_url, auth)
        state = status_data.get("state", "")

        if state == "completed":
            outputs = status_data.get("output", [])
            if not outputs:
                raise RuntimeError("Generation completed but no output returned.")
            video_url = outputs[0].get("url")
            if not video_url:
                raise RuntimeError("Generation completed but no video URL in output.")
            # Presigned URLs expire after 1 hour - download immediately
            return _download_bytes(video_url)

        if state == "failed":
            reason = status_data.get("failure_reason") or status_data.get("failure_code") or "unknown"
            raise RuntimeError("Luma video generation failed: {}".format(reason))

        time.sleep(POLL_INTERVAL_SECONDS)

    raise RuntimeError(
        "Luma video generation did not finish within {} poll attempts (~{} minutes). "
        "The generation may still complete on Luma's end — check "
        "https://platform.lumalabs.ai/ or try again.".format(
            MAX_POLL_ATTEMPTS,
            (INITIAL_POLL_WAIT_SECONDS + MAX_POLL_ATTEMPTS * POLL_INTERVAL_SECONDS) // 60,
        )
    )


def save_video(video_bytes, still_path):
    video_path = still_path.replace("AIArchVideoStill", "AIArchVideo")
    if video_path.lower().endswith(".png"):
        video_path = video_path[:-4] + ".mp4"
    else:
        video_path += ".mp4"
    DotNetFile.WriteAllBytes(video_path, video_bytes)
    return video_path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    doc = revit.doc
    gemini_key = get_gemini_key()
    luma_key = get_luma_key()
    view = get_active_3d_view()

    xaml_path = script.get_bundle_file("ui.xaml")
    (last_style_index, last_image_quality_index, last_video_quality_index,
     last_extra, last_motion) = load_last_settings()
    recent_extras = get_recent_extras()
    recent_motions = get_recent_motions()

    prompt_form = PromptForm(
        xaml_path, doc, view, gemini_key, luma_key,
        last_style_index, last_image_quality_index, last_video_quality_index,
        last_extra, recent_extras, last_motion, recent_motions
    )
    prompt_form.ShowDialog()


if __name__ == "__main__":
    main()
