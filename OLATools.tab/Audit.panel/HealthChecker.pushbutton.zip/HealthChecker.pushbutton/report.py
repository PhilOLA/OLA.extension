# -*- coding: utf-8 -*-
"""
report.py  —  Model Health Checker
Export engine: CSV, Excel (.xlsx via openpyxl), and JSON.

Public API (called from script.py)
-----------------------------------
  export_csv (results, score, counts, folder, base_name)  →  str (path)
  export_xlsx(results, score, counts, folder, base_name)  →  str (path)
  export_json(results, score, counts, folder, base_name)  →  str (path)

Each function returns the absolute path of the file written.
Raises on failure — callers in script.py already catch and surface errors.

CSV format
----------
One sheet — flat table, one row per flagged item:
  Category | Check | Status | Count | Element ID | Name | Detail | Issue

Excel format
------------
Sheet 1 — Summary    : score, counts, one row per check
Sheet 2 — All items  : same flat table as CSV
Sheet 3 — Trend      : score history from snapshots (if any)
Colour-coded by status (green / amber / red / grey).
No external dependencies beyond openpyxl.

JSON format
-----------
Full results dict serialised, with metadata header.

openpyxl notes
--------------
openpyxl is a pure-Python library.  IronPython 2 can run it via
  pip install openpyxl --target <bundle_dir>/vendor
and importing with sys.path manipulation.  The code handles the case
where openpyxl is absent and falls back to a warning.
"""

import os
import sys
import csv
import json
import datetime

# ---------------------------------------------------------------------------
# openpyxl — optional, loaded from vendor/ subfolder if present
# ---------------------------------------------------------------------------
_BUNDLE_DIR = os.path.dirname(os.path.abspath(__file__))
_VENDOR_DIR = os.path.join(_BUNDLE_DIR, 'vendor')
if os.path.exists(_VENDOR_DIR) and _VENDOR_DIR not in sys.path:
    sys.path.insert(0, _VENDOR_DIR)

_OPENPYXL_AVAILABLE = False
try:
    import openpyxl
    from openpyxl.styles import (
        PatternFill, Font, Alignment, Border as XlBorder, Side,
    )
    from openpyxl.utils import get_column_letter
    from openpyxl.chart import LineChart, Reference
    _OPENPYXL_AVAILABLE = True
except ImportError:
    pass

# snapshots imported lazily inside export_xlsx to avoid circular issues
# (snapshots imports nothing from report)

# ---------------------------------------------------------------------------
# Colour constants for Excel
# ---------------------------------------------------------------------------
XL_FAIL_BG   = 'FF3A1A1A'
XL_WARN_BG   = 'FF3A2E10'
XL_OK_BG     = 'FF1A3A2A'
XL_INFO_BG   = 'FF222222'
XL_HEADER_BG = 'FF1E1E1E'
XL_BG        = 'FF262626'

XL_FAIL_FG   = 'FFEF5350'
XL_WARN_FG   = 'FFFFB74D'
XL_OK_FG     = 'FF4DB6AC'
XL_INFO_FG   = 'FF888780'
XL_HEADER_FG = 'FF4FC3F7'
XL_TEXT_FG   = 'FFCCCCCC'
XL_MUTED_FG  = 'FF888780'

_STATUS_BG = {
    'OK':    XL_OK_BG,
    'WARN':  XL_WARN_BG,
    'FAIL':  XL_FAIL_BG,
    'INFO':  XL_INFO_BG,
    'ERROR': XL_FAIL_BG,
}
_STATUS_FG = {
    'OK':    XL_OK_FG,
    'WARN':  XL_WARN_FG,
    'FAIL':  XL_FAIL_FG,
    'INFO':  XL_INFO_FG,
    'ERROR': XL_FAIL_FG,
}

# Category display order and labels
_CATEGORY_ORDER = ['bloat', 'integrity', 'coordination', 'performance', 'parameters']
_CATEGORY_LABELS = {
    'bloat':        'Model bloat',
    'integrity':    'Data integrity',
    'coordination': 'Coordination',
    'performance':  'Performance',
    'parameters':   'Parameters',
}

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _timestamp():
    return datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')


def _flatten_items(results):
    """
    Yield flat rows from all check results, ordered by category then check.
    Each row: (category_label, check_label, status, total_count,
               elem_id, name, detail, issue_note)
    """
    # build ordered list of (key, result) by category
    import checks as chk
    check_meta = {c[0]: c for c in chk.CHECKS}
    ordered = []
    for cat in _CATEGORY_ORDER:
        for c in chk.CHECKS:
            key = c[0]
            if c[3] == cat and key in results:
                ordered.append((key, results[key]))

    for key, result in ordered:
        meta       = check_meta.get(key)
        cat_label  = _CATEGORY_LABELS.get(meta[3], meta[3]) if meta else ''
        chk_label  = result.get('label', key)
        status     = result.get('status', 'ERROR')
        total      = result.get('count', 0)
        items      = result.get('items', [])

        if not items:
            # emit one summary row even for OK checks
            yield (cat_label, chk_label, status, total,
                   '', '', '', result.get('message', ''))
            continue

        for item in items:
            elem_id = str(item.get('id', ''))
            name = (item.get('name') or item.get('view_name') or
                    item.get('description') or item.get('param_name') or
                    item.get('filename') or '')
            detail = (item.get('category') or item.get('level') or
                      item.get('view_type') or item.get('group_type') or
                      item.get('datatype') or item.get('link_type') or '')
            issue = (item.get('issue_type') or item.get('status') or
                     item.get('issue') or '')
            yield (cat_label, chk_label, status, total,
                   elem_id, name, detail, issue)


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------

def export_csv(results, score, counts, folder, base_name):
    """
    Write a flat CSV with one row per flagged item.
    Returns the path written.
    """
    path = os.path.join(folder, base_name + '.csv')

    rows = list(_flatten_items(results))

    with open(path, 'w') as f:
        # IronPython 2: csv.writer needs a file opened in text mode
        writer = csv.writer(f, lineterminator='\r\n')

        # Metadata header block
        writer.writerow(['Model Health Checker — Export'])
        writer.writerow(['Generated', _timestamp()])
        writer.writerow(['Health score', score])
        writer.writerow(['OK',    counts.get('OK',    0)])
        writer.writerow(['WARN',  counts.get('WARN',  0)])
        writer.writerow(['FAIL',  counts.get('FAIL',  0)])
        writer.writerow(['INFO',  counts.get('INFO',  0)])
        writer.writerow([])

        # Column headers
        writer.writerow([
            'Category', 'Check', 'Status', 'Total count',
            'Element ID', 'Name / description', 'Detail', 'Issue note',
        ])

        for row in rows:
            writer.writerow(list(row))

    return path


# ---------------------------------------------------------------------------
# Excel export
# ---------------------------------------------------------------------------

def export_xlsx(results, score, counts, folder, base_name):
    """
    Write a styled Excel workbook with Summary, All Items, and Trend sheets.
    Returns the path written.
    Raises ImportError with a clear message if openpyxl is not available.
    """
    if not _OPENPYXL_AVAILABLE:
        raise ImportError(
            'openpyxl is not installed.\n'
            'Run: pip install openpyxl --target '
            '"{}"'.format(_VENDOR_DIR))

    path = os.path.join(folder, base_name + '.xlsx')
    wb   = openpyxl.Workbook()

    _build_summary_sheet(wb, results, score, counts)
    _build_items_sheet(wb, results)
    _build_trend_sheet(wb)

    wb.save(path)
    return path


def _xl_fill(hex_colour):
    return PatternFill('solid', fgColor=hex_colour)

def _xl_font(hex_colour, bold=False, size=10):
    return Font(color=hex_colour, bold=bold, size=size, name='Consolas')

def _xl_align(h='left', v='center', wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def _xl_border():
    thin = Side(style='thin', color='FF333333')
    return XlBorder(bottom=thin)

def _xl_header_row(ws, cols, row=1, bg=XL_HEADER_BG, fg=XL_HEADER_FG):
    """Write a header row and return the row number used."""
    for col_idx, text in enumerate(cols, 1):
        cell = ws.cell(row=row, column=col_idx, value=text)
        cell.fill      = _xl_fill(bg)
        cell.font      = _xl_font(fg, bold=True, size=10)
        cell.alignment = _xl_align('left', 'center')
        cell.border    = _xl_border()
    return row


def _build_summary_sheet(wb, results, score, counts):
    """Sheet 1 — Summary: score block + one row per check."""
    import checks as chk

    ws = wb.active
    ws.title = 'Summary'
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = 'FF4FC3F7'

    # Set column widths
    col_widths = [20, 32, 10, 10, 42]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    # --- Score block (rows 1–6) ---
    ws.merge_cells('A1:E1')
    title_cell = ws['A1']
    title_cell.value     = 'Model Health Checker — Report'
    title_cell.fill      = _xl_fill(XL_HEADER_BG)
    title_cell.font      = _xl_font(XL_HEADER_FG, bold=True, size=12)
    title_cell.alignment = _xl_align('left', 'center')

    meta_rows = [
        ('Generated',    _timestamp()),
        ('Health score', score),
        ('OK checks',    counts.get('OK',   0)),
        ('WARN checks',  counts.get('WARN', 0)),
        ('FAIL checks',  counts.get('FAIL', 0)),
    ]
    score_fgs = {
        'Health score': XL_WARN_FG if score < 80 else XL_OK_FG,
    }
    for i, (label, value) in enumerate(meta_rows, 2):
        label_cell = ws.cell(row=i, column=1, value=label)
        value_cell = ws.cell(row=i, column=2, value=value)
        label_cell.fill = _xl_fill(XL_BG)
        value_cell.fill = _xl_fill(XL_BG)
        label_cell.font = _xl_font(XL_MUTED_FG, size=10)
        fg = score_fgs.get(label, XL_TEXT_FG)
        if label == 'Health score':
            fg = XL_OK_FG if score >= 80 else (XL_WARN_FG if score >= 50 else XL_FAIL_FG)
        value_cell.font = _xl_font(fg, bold=(label == 'Health score'), size=10)
        label_cell.alignment = _xl_align()
        value_cell.alignment = _xl_align()

    # blank row
    for col in range(1, 6):
        ws.cell(row=7, column=col).fill = _xl_fill(XL_BG)

    # --- Check table header (row 8) ---
    headers = ['Category', 'Check', 'Status', 'Count', 'Message']
    _xl_header_row(ws, headers, row=8)

    # --- Check rows ---
    check_meta = {c[0]: c for c in chk.CHECKS}
    row_num = 9
    prev_cat = None

    for cat in _CATEGORY_ORDER:
        cat_checks = [c for c in chk.CHECKS if c[3] == cat]
        for c in cat_checks:
            key = c[0]
            if key not in results:
                continue
            result  = results[key]
            status  = result.get('status', 'ERROR')
            count   = result.get('count', 0)
            message = result.get('message', '')
            label   = result.get('label', key)
            cat_label = _CATEGORY_LABELS.get(cat, cat)

            # category separator row
            if cat != prev_cat:
                for col in range(1, 6):
                    cell = ws.cell(row=row_num, column=col)
                    cell.fill = _xl_fill(XL_HEADER_BG)
                    cell.font = _xl_font(XL_MUTED_FG, size=9)
                ws.cell(row=row_num, column=1).value = cat_label.upper()
                ws.cell(row=row_num, column=1).font = _xl_font(
                    XL_MUTED_FG, bold=True, size=9)
                row_num += 1
                prev_cat = cat

            bg = _STATUS_BG.get(status, XL_INFO_BG)
            fg = _STATUS_FG.get(status, XL_MUTED_FG)

            vals = [cat_label, label, status, count, message]
            for col_idx, val in enumerate(vals, 1):
                cell = ws.cell(row=row_num, column=col_idx, value=val)
                cell.fill = _xl_fill(bg if col_idx in (3, 4) else XL_BG)
                cell.font = _xl_font(fg if col_idx in (3, 4) else XL_TEXT_FG, size=10)
                cell.alignment = _xl_align(wrap=(col_idx == 5))
                cell.border = _xl_border()
            row_num += 1

    # freeze top rows
    ws.freeze_panes = 'A9'


def _build_items_sheet(wb, results):
    """Sheet 2 — All items: flat table matching the CSV output."""
    ws = wb.create_sheet(title='All items')
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = 'FF262626'

    col_widths = [18, 28, 8, 8, 12, 36, 20, 28]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    headers = [
        'Category', 'Check', 'Status', 'Total',
        'Element ID', 'Name / description', 'Detail', 'Issue note',
    ]
    _xl_header_row(ws, headers, row=1)

    rows = list(_flatten_items(results))
    prev_status = None

    for i, row in enumerate(rows, 2):
        cat, chk_label, status, total, elem_id, name, detail, issue = row
        bg = _STATUS_BG.get(status, XL_INFO_BG)
        fg = _STATUS_FG.get(status, XL_MUTED_FG)

        vals = [cat, chk_label, status, total, elem_id, name, detail, issue]
        for col_idx, val in enumerate(vals, 1):
            cell = ws.cell(row=i, column=col_idx, value=val)
            # status and total get the status colour; others stay neutral
            if col_idx in (3, 4):
                cell.fill = _xl_fill(bg)
                cell.font = _xl_font(fg, bold=(col_idx == 3), size=10)
            else:
                cell.fill = _xl_fill(XL_BG)
                cell.font = _xl_font(XL_TEXT_FG, size=10)
            cell.alignment = _xl_align(wrap=(col_idx in (6, 8)))
            cell.border    = _xl_border()

    ws.freeze_panes = 'A2'

    # auto-filter
    if rows:
        ws.auto_filter.ref = 'A1:{}{}'.format(
            get_column_letter(8), len(rows) + 1)


def _build_trend_sheet(wb):
    """
    Sheet 3 — Trend: score history from snapshots as a table and line chart.
    Silently skipped if snapshots module is unavailable or no history exists.
    """
    try:
        import snapshots
        # doc not available here — use the module-level __revit__ would need
        # passing in; instead snapshots exposes a path-based API.
        # We read the store directly via the doc reference carried in the
        # Revit context.  Since report.py is imported lazily at export time,
        # __revit__ is in scope via the IronPython script globals.
        # Fall back gracefully if we can't get it.
        try:
            doc = __revit__.ActiveUIDocument.Document
        except Exception:
            return

        history = snapshots.get_score_history(doc, limit=20)
        if not history:
            return

        ws = wb.create_sheet(title='Trend')
        ws.sheet_view.showGridLines = False
        ws.sheet_properties.tabColor = 'FF1E2A38'

        ws.column_dimensions['A'].width = 22
        ws.column_dimensions['B'].width = 12

        headers = ['Date / time', 'Health score']
        _xl_header_row(ws, headers, row=1)

        # history is newest-first; reverse for chart (oldest left)
        history_asc = list(reversed(history))

        for i, (ts, sc) in enumerate(history_asc, 2):
            ts_cell = ws.cell(row=i, column=1, value=ts)
            sc_cell = ws.cell(row=i, column=2, value=sc)

            ts_cell.fill = _xl_fill(XL_BG)
            ts_cell.font = _xl_font(XL_MUTED_FG, size=10)
            ts_cell.alignment = _xl_align()

            # colour the score cell by value
            if sc >= 80:
                sc_fg = XL_OK_FG
                sc_bg = XL_OK_BG
            elif sc >= 50:
                sc_fg = XL_WARN_FG
                sc_bg = XL_WARN_BG
            else:
                sc_fg = XL_FAIL_FG
                sc_bg = XL_FAIL_BG
            sc_cell.fill      = _xl_fill(sc_bg)
            sc_cell.font      = _xl_font(sc_fg, bold=True, size=10)
            sc_cell.alignment = _xl_align('center')
            sc_cell.border    = _xl_border()

        # Line chart
        if len(history_asc) >= 2:
            chart = LineChart()
            chart.title  = 'Health score over time'
            chart.y_axis.title  = 'Score'
            chart.x_axis.title  = 'Run'
            chart.style  = 10
            chart.height = 12
            chart.width  = 22

            data_ref = Reference(
                ws,
                min_col=2, max_col=2,
                min_row=1, max_row=len(history_asc) + 1)
            chart.add_data(data_ref, titles_from_data=True)
            chart.series[0].graphicalProperties.line.solidFill  = '4FC3F7'
            chart.series[0].graphicalProperties.line.width = 20000  # EMUs

            ws.add_chart(chart, 'D2')

        ws.freeze_panes = 'A2'

    except Exception:
        # trend sheet is optional — any failure is silently swallowed
        pass


# ---------------------------------------------------------------------------
# JSON export
# ---------------------------------------------------------------------------

def export_json(results, score, counts, folder, base_name):
    """
    Write the full results dict as JSON with a metadata header.
    Returns the path written.
    """
    path = os.path.join(folder, base_name + '.json')

    # Build a fully serialisable copy of results
    # (items lists may contain int ElementIds which are already Python ints)
    serialisable = {}
    for key, result in results.items():
        serialisable[key] = {
            'label':    result.get('label', key),
            'category': result.get('category', ''),
            'status':   result.get('status', 'ERROR'),
            'count':    result.get('count', 0),
            'message':  result.get('message', ''),
            'items':    _serialise_items(result.get('items', [])),
        }

    payload = {
        'meta': {
            'tool':      'Model Health Checker',
            'version':   '1.0.0',
            'generated': _timestamp(),
            'score':     score,
            'counts':    counts,
        },
        'results': serialisable,
    }

    with open(path, 'w') as f:
        json.dump(payload, f, indent=2, default=_json_default)

    return path


def _serialise_items(items):
    """Return a JSON-safe copy of an items list."""
    out = []
    for item in items:
        clean = {}
        for k, v in item.items():
            clean[k] = _json_default(v) if not _is_json_native(v) else v
        out.append(clean)
    return out


def _is_json_native(v):
    return isinstance(v, (bool, int, float, str, list, dict, type(None)))


def _json_default(obj):
    """Fallback JSON serialiser for non-native types."""
    try:
        return int(obj)
    except (TypeError, ValueError):
        pass
    try:
        return str(obj)
    except Exception:
        return None
